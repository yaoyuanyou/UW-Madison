#!/bin/bash
mkdir ten;
v=$( seq -w 1 10 );
u=$( seq 1 4);
for i in $v;do
mkdir ten/dir$i;
	for j in $u;do
		w=$( seq 1 $((j-1)) );
	echo $j > ten/dir$i/file$j.txt;
	for l in $w;do
	       echo $j >> ten/dir$i/file$j.txt;	
	done
	done
done
