#!/bin/bash
col=$1;
file=$2;
echo "USAGE $0<$col>[$file]"
if [ ! -n "$col" ];then
       echo "USAGE $0, no column input.";
exit 1;
fi;
if [ -n "$3" ];then
	echo "USAGE $0, too many arguments.";
	exit 1;
fi;
cat $file|cut -d ',' -f  $col|tail -n +2|{
my_sum=0;num_lines=0; while read line; do
my_sum=$(( $my_sum + $line ));
num_lines=$(( $num_lines + 1 ));
done; echo $(( $my_sum / $num_lines ));}
