#!/bin/bash
dir=$1;
n=$2;
echo "USAGE: $0 <$dir> <$n>"
if [ ! -n "$n" ];then
	echo "fewer arguments are supplied.";
	exit 1;
fi
if [ -n "$3" ];then
	echo "more arguments are supplied.";
	exit 1;
fi
if 	[ ! -d $dir ];then
	echo "ERROR:input is not a directory.";
else 
	rm  $(find $dir -size -"$n"c);
fi

