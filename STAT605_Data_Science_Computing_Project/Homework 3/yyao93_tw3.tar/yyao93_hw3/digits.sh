#!/bin/bash

seq 1000 2000 | grep 2 |wc -l
